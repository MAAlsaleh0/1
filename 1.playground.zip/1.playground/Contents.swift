// المتغيرات والثوابت

// متغير
var age : Int = 19
// ثابت
let name : String = "Mohammed"

print("Hello , \(name)")

// العمليات الرياضية

// الجمع
var plus : Int = 10 + 10
print(plus)
// 20
// الطرح
var min : Int = 20 - 10
print(min)
// 10
// الضرب
var multiply : Int = 10 * 10
print(multiply)
//100
// القسمة
var div : Int = 6 / 2
print(div)
// 3
// باقي القسمة
var div1 : Int = 7 % 2
print(div1)
// 1

// المتغيرات الإختيارية


var marks : Int?
marks = 10
// طريقة فك المتغيرات الإختيارية
print(marks ?? 0)

// العبارات الشرطية

var myAge : Int = 17
let myName : String = "Ali"

// و ، أو

if myName != "Mohammed" {
    print("اسمك ليس محمد")
} else {
    print("اسمك  محمد")
}

// العمليات المنطقية

var trueB : Bool = true
var falseB : Bool = false

print(!falseB)
